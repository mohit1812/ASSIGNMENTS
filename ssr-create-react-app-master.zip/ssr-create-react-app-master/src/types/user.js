const prefix = 'USER/'

export const SET = prefix + 'SET'
export const RESET = prefix + 'RESET'

